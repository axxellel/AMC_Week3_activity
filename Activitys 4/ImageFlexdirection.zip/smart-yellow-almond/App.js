import React from 'react';
import {StyleSheet, TextInput, Image, View} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInputExample = () => {
  const [text, onChangeTextName] = React.useState('Name:');
  const [number, onChangeTextAge] = React.useState('Age:');
  const [Address, onChangeTextAddress] = React.useState('Address:');
  const [School, onChangeTextSchool] = React.useState('School:');
  const [Course, onChangeTextCourse] = React.useState('Course:');
  const [Email, onChangeTextEmail] = React.useState('Email:');
  const [Contact, onChangeTextContact] = React.useState('Contact no: ');

  return (
    <SafeAreaProvider>
      <SafeAreaView>
        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://www.pngitem.com/pimgs/m/78-786293_1240-x-1240-0-avatar-profile-icon-png.png' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextName}
            value={text}
            placeholder="Name"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://cdn2.iconfinder.com/data/icons/spa-solid-icons-1/48/25-512.png' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextAge}
            value={number}
            placeholder="Age:"
            keyboardType="numeric"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://th.bing.com/th/id/OIP.tTTBZqNjESaqecgA68fthwHaIN?rs=1&pid=ImgDetMain' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextAddress}
            value={Address}
            placeholder="Address"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://th.bing.com/th/id/OIP.thT7JtcF3hzYAvKEdlHoIQHaHa?rs=1&pid=ImgDetMain' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextSchool}
            value={School}
            placeholder="School"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://w7.pngwing.com/pngs/575/29/png-transparent-computer-icons-instructor-led-training-course-education-toolbox-miscellaneous-blue-angle.png' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextCourse}
            value={Course}
            placeholder="Course"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://purepng.com/public/uploads/large/purepng.com-mail-iconsymbolsiconsapple-iosiosios-8-iconsios-8-721522596075clftr.png' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextEmail}
            value={Email}
            placeholder="Email"
          />
        </View>

        <View style={styles.inputContainer}>
          <Image source={{ uri: 'https://th.bing.com/th/id/OIP.Jn4akHboFQz85B8l93dwzwAAAA?rs=1&pid=ImgDetMain' }} style={styles.icon} />
          <TextInput
            style={styles.input}
            onChangeText={onChangeTextContact}
            value={Contact}
            placeholder="Contact"
          />
        </View>

        <MultilineTextInputExample />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const MultilineTextInputExample = () => {
  const [aboutme, onChangeTextAboutme] = React.useState('About me: Hello i am Axzyl L. Valad-on I am Currenly taking BSIT in GRC ');
  
  return (
    <SafeAreaProvider>
      <SafeAreaView
        style={[
          multilineStyles.container,
          {
            backgroundColor: aboutme,
          },
        ]}>
        <TextInput
          editable
          multiline
          numberOfLines={3}
          maxLength={40}
          onChangeText={text => onChangeTextAboutme(text)}
          value={aboutme}
          style={multilineStyles.textInput}
        />
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 1,
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 10,
  },
  input: {
    flex: 1,
    height: 40,
    borderWidth: 1,
    padding: 10,
  },
});

const multilineStyles = StyleSheet.create({
  container: {
    borderBottomColor: '#000',
    borderTopWidth: 0,
    borderBottomWidth: 0,
  },
  textInput: {
    padding: 1,
    alignItems: 'center',
    margin: 1,
    borderWidth: 1,
    borderBottomWidth: 1,
  },
});

export default TextInputExample;
